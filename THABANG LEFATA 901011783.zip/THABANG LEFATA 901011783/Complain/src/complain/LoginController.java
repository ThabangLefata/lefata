/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class LoginController implements Initializable {
    
     @FXML
    private JFXTextField lbid;

    @FXML
    private JFXPasswordField lbpass;

    @FXML
    private Button btnsignin;

    @FXML
    private Button btnsignup;
    
    
    @FXML
    private Label lblError;
    
    @FXML
    private AnchorPane loginPane;
    @FXML
    private AnchorPane paneAdmin;
    @FXML
    private Button btnAdmin;
    @FXML
    private Button btnUser;
    @FXML
    private AnchorPane paneUsers;
    @FXML
    private JFXTextField lbid1;
    @FXML
    private JFXPasswordField lbpass1;
    @FXML
    private Label lblError1;
    @FXML
    private Button btnsignin1;
    @FXML
    private Button btnsignup1;
    
   
    

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    } 
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
   /* private void Login() throws IOException {
        String id = lbid.getText();
        String password = lbpass.getText();
      
        
        
        {
             try{
                conn = Mysqlconnect.ConnectDb();
              String sql = "Select * from users where id = ? and password = ?";
                
            pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.setString(2, password);
          
            rs = pst.executeQuery();
            
             if(!rs.next()){
                lblError.setTextFill(Color.TOMATO);
                lblError.setText("You Entered wrong Id/Password");
                System.err.println("Please try again");
               // return "erro";
               
             }
             else{
              
                 
                lblError.setTextFill(Color.GREEN);
                lblError.setText("Welcome");
                System.err.println("You Locked In");
                
               
                
            
               AnchorPane pane = FXMLLoader.load(getClass().getResource("Dashhhhh.fxml"));
               loginPane.getChildren().setAll(pane);
             }
            }catch(SQLException ex)
        {
            System.err.println(ex.getMessage());
            //return "Exception";
        }
        }
    }*/

    private void Signup(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        loginPane.getChildren().setAll(pane);
    }

    @FXML
    private void goToAdmin(ActionEvent event) {
                  paneAdmin.setVisible(true);
                  paneUsers.setVisible(false);
        
    }

    @FXML
    private void goToUser(ActionEvent event) {
                  paneAdmin.setVisible(false);
                  paneUsers.setVisible(true);
    }

    @FXML
    private void LoginAmin(ActionEvent event) throws IOException {
                       String id = lbid.getText();
        String password = lbpass.getText();
      
        
        
        {
             try{
                conn = Mysqlconnect.ConnectDb();
              String sql = "Select * from users where id = ? and password = ?";
                
            pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            pst.setString(2, password);
          
            rs = pst.executeQuery();
            
             if(!rs.next()){
                lblError.setTextFill(Color.TOMATO);
                lblError.setText("You Entered wrong Id/Password");
                System.err.println("Please try again");
               // return "erro";
               
             }
             else{
              
                 
                lblError.setTextFill(Color.GREEN);
                lblError.setText("Welcome");
                System.err.println("You Locked In");
                
               
                
            
               AnchorPane pane = FXMLLoader.load(getClass().getResource("Dashhhhh.fxml"));
               loginPane.getChildren().setAll(pane);
             }
            }catch(SQLException ex)
        {
            System.err.println(ex.getMessage());
            //return "Exception";
        }
        }
    }

    @FXML
    private void SignupAdmin(ActionEvent event) {
    }

    @FXML
    private void LoginUser(ActionEvent event) throws IOException {
                String id1 = lbid1.getText();
                String password1 = lbpass1.getText();
      
        
        
        {
             try{
                conn = Mysqlconnect.ConnectDb();
              String sql = "Select * from users where id = ? and password = ?";
                
            pst = conn.prepareStatement(sql);
            pst.setString(1, id1);
            pst.setString(2, password1);
          
            rs = pst.executeQuery();
            
             if(!rs.next()){
                lblError1.setTextFill(Color.TOMATO);
                lblError1.setText("You Entered wrong Id/Password");
                System.err.println("Please try again");
               // return "erro";
               
             }
             else{
              
                 
                lblError.setTextFill(Color.GREEN);
                lblError.setText("Welcome");
                System.err.println("You Locked In");
                
               
                
            
               AnchorPane pane = FXMLLoader.load(getClass().getResource("ComplainFromUser.fxml"));
               loginPane.getChildren().setAll(pane);
             }
            }catch(SQLException ex)
        {
            System.err.println(ex.getMessage());
            //return "Exception";
        }
        }
             
    }

    @FXML
    private void SignupUser(ActionEvent event) throws IOException {
                AnchorPane pane = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
              loginPane.getChildren().setAll(pane);
    }
}
