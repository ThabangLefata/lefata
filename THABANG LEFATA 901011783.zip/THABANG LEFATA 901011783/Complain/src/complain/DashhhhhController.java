/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import complain.usermodels.Complains;
import complain.usermodels.Users;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javax.swing.JOptionPane;


public class DashhhhhController implements Initializable {

    @FXML
    private AnchorPane mainPane;
    @FXML
    private Button btnhome;
    @FXML
    private Button btnprofile;
    @FXML
    private Button btnusers;
    @FXML
    private Button btncomplains;
    @FXML
    private Button btnlogout;
    @FXML
    private AnchorPane painUsers;
    @FXML
   
    private TableView<Users> tableview_users;
    @FXML
    private TableColumn<Users, String> idcolumn;
    @FXML
    private TableColumn<Users, String> namecolumn;
    @FXML
    private TableColumn<Users, String> lastnamecolumn;
    @FXML
    private TableColumn<Users, String> catergorycolumn;
    @FXML
    private TableColumn<Users, String> emailColum;

   
    String query = null;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    Users user = null;
    
    
    @FXML
    private AnchorPane paneComplains;
    @FXML
    private TableView<Complains> tableComplain;
    @FXML
    private TableColumn<Complains, String> columcomplaintype;
    @FXML
    private TableColumn<Complains, String> columcomplainComplain;
    @FXML
    private TableColumn<Complains, String>columnactionComplain;
    @FXML
    private FontAwesomeIconView btnsearch1;
    @FXML
    private FontAwesomeIconView btnrefresh1;
    @FXML
    private Button adduser1;
    @FXML
    private FontAwesomeIconView btnsearch;
    @FXML
    private FontAwesomeIconView btnrefresh;
    @FXML
    private Button adduser;
    @FXML
    private Pane paneStatusUsers;
    @FXML
    private Label lablestatus;
    
    ObservableList<Users> UsersList = FXCollections.observableArrayList();
    ObservableList<Complains> ComplainList = FXCollections.observableArrayList();
    
    @FXML
    private Button adduser11;
    @FXML
    private Button adduser111;
    @FXML
    private TextField searchId;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       // catergorycolumn.getItems().addAll("Student","Lecture", "Security","Cleaners");
        loadUser();
        loadComplains();
    }    


  
 
    private void loadUser() {
       try{
         conn = Mysqlconnect.ConnectDb();
         ResultSet rs = conn.createStatement().executeQuery("select * from users");
         while (rs.next()){
         
             UsersList.add(new Users(rs.getString("id"),
             rs.getString("name"), rs.getString("lastname"),rs.getString("email"),rs.getString("catergory")));
         }
       }catch(SQLException ex){
       Logger.getLogger(AddingUserController.class.getName()).log(Level.SEVERE, null,ex);
       }
        
       idcolumn.setCellValueFactory(new PropertyValueFactory<>("id"));
       namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
       lastnamecolumn.setCellValueFactory(new PropertyValueFactory<>("lastname"));
       
       emailColum.setCellValueFactory(new PropertyValueFactory<>("email"));
       catergorycolumn.setCellValueFactory(new PropertyValueFactory<>("catergory"));
       
       tableview_users.setItems(UsersList);
    }
    private void loadComplains(){
            try{
         conn = Mysqlconnect.ConnectDb();
         ResultSet rs = conn.createStatement().executeQuery("select * from complains");
         while (rs.next()){
         
             ComplainList.add(new Complains(
             rs.getString("catergory"), rs.getString("complain")));
         }
       }catch(SQLException ex){
       Logger.getLogger(AddingUserController.class.getName()).log(Level.SEVERE, null,ex);
       }
            columcomplaintype.setCellValueFactory(new PropertyValueFactory<>("category"));
            columcomplainComplain.setCellValueFactory(new PropertyValueFactory<>("complain"));
           
            
            tableComplain.setItems(ComplainList);
    
    }
 
    
     @FXML
    private void handleClicks(ActionEvent event) throws IOException
    {
      if(event.getSource() == btnusers)
          
        
      {
          paneComplains.setVisible(false);
          painUsers.setVisible(true);
          lablestatus.setText("Registered Users"); 
        //paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
      }else
                if(event.getSource() == btncomplains )
      {
          paneComplains.setVisible(true);
          painUsers.setVisible(false);
          lablestatus.setText("Complaints Of School"); 
          //paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
      
      }else
             if(event.getSource() == btnprofile)
      {
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Profile.fxml"));
              mainPane.getChildren().setAll(pane);
      
      }else if (event.getSource() == btnlogout)
            {
              AnchorPane pane = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
              mainPane.getChildren().setAll(pane);
        } else{
      
         }            
    }

    @FXML
    private void refreshTable(MouseEvent event) {
    }

    @FXML
    private void Delete(ActionEvent event) {
       conn = Mysqlconnect.ConnectDb();
        String sql = "delete from users where id=?";
        try{
             pst = conn.prepareStatement(sql);
             pst.setString(1,searchId.getText());
             pst.execute();
             JOptionPane.showMessageDialog(null, "Deleted");
             loadUser();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }

    @FXML
    private void AddUser() throws IOException {
               AnchorPane pane = FXMLLoader.load(getClass().getResource("InsertUser.fxml"));
               mainPane.getChildren().setAll(pane);
    }
    
        
}
