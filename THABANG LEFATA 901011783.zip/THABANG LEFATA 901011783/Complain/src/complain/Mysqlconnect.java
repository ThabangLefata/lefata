      
package complain;

import java.sql.Connection;
import java.sql.DriverManager;


public class Mysqlconnect {
   Connection conn = null; 
   public static Connection ConnectDb(){
       try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/complain","root","");
          // JOptionPane.showMessageDialog(null, "Connected");
           return conn;
       }catch (Exception ex){
           System.out.println("Connected"+ex.getMessage());
            return null;
       }
       
   
   }
}
