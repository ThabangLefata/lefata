/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Pane;


public class DashboardController implements Initializable {

    @FXML
    private Button btnhome;
    @FXML
    private Button btnprofile;
    @FXML
    private Button btnusers;
    @FXML
    private Button btncomplains;
    @FXML
    private Button btnlogout;
    @FXML
    private TableView<?> tableview_users;
    @FXML
    private TableColumn<?, ?> idcolumn;
    @FXML
    private TableColumn<?, ?> namecolumn;
    @FXML
    private TableColumn<?, ?> lastnamecolumn;
    @FXML
    private TableColumn<?, ?> catergorycolumn;
    @FXML
    private TableColumn<?, ?> catergorycolumn1;
    @FXML
    private TableColumn<?, ?> catergorycolumn11;
    @FXML
    private Pane paneStatusUsers;
    @FXML
    private Label lablestatus;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    @FXML
    private void handleClicks(ActionEvent event) throws IOException
    {
      if(event.getSource() == btnusers)
      {
            lablestatus.setText("Registered Users"); 
        //paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
      }else
                if(event.getSource() == btncomplains )
      {
           lablestatus.setText("Complaints Of School"); 
          //paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
      
      }else
             if(event.getSource() == btnprofile)
      {
          lablestatus.setText("Profile");
      
      }else if (event.getSource() == btnlogout)
            {
             
        } else{
      
         }            
    }
    
}
