

package complain;

import static java.awt.Color.red;
import java.awt.Insets;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;


public class DashController implements Initializable {

    @FXML
    private Button btnhome;
    @FXML
    private Button btnprofile;
    @FXML
    private Button btnusers;
    @FXML
    private Button btncomplains;
    @FXML
    private Button btnlogout;
    @FXML
    private TableView<?> tableview_users;
    @FXML
    private TableColumn<?, ?> idcolumn;
    @FXML
    private TableColumn<?, ?> namecolumn;
    @FXML
    private TableColumn<?, ?> lastnamecolumn;
    @FXML
    private TableColumn<?, ?> catergorycolumn;
    @FXML
    private TableColumn<?, ?> catergorycolumn1;
    @FXML
    private TableColumn<?, ?> catergorycolumn11;
    @FXML
    private Pane paneStatusUsers;
    @FXML
    private Label lablestatus;
    @FXML
    private GridPane showstudents;
    @FXML
    private GridPane shocomplains;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    @FXML
    private void handleClicks(ActionEvent event)
    {
      if(event.getSource() == btnusers)
      {
            lablestatus.setText("Registered Users"); 
        // paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
            showstudents.toFront();
      }else
                if(event.getSource() == btncomplains )
      {
           lablestatus.setText("Complaints Of School"); 
           shocomplains.toFront();
          // paneStatusUsers.setBackground(new Background (new BackgroundFill(Color.rgb(red:63, green:43, blue:99), CornerRadii.EMPTY, Insets.EMPTY)));
      
      }else
             if(event.getSource() == btnprofile)
      {
          lablestatus.setText("Profile");
      
      }else if (event.getSource() == btnlogout)
            {
             lablestatus.setText("Log Out");
        } else{
      
         }            
    }
    
}

      
    

