/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import java.awt.HeadlessException;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class ComplainFromUserController implements Initializable {

    @FXML
    private Button btnhome;
    @FXML
    private Button btnprofile;
    @FXML
    private Button btncomplains;
    @FXML
    private Button btnlogout;
    @FXML
    private AnchorPane paneUsercomplain;
    @FXML
    private Pane paneStatusUsers;
    @FXML
    private Label lablestatus;
    @FXML
    private TextArea txtcomplainarea;
    @FXML
    private Button btnsedComplain;
    @FXML
    private ComboBox typeCombo;
    
    java.sql.Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    @FXML
    private AnchorPane paneComplaining;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      typeCombo.getItems().addAll("Student","Lecture", "Security","Management","Others");  
    }    

    @FXML
    private void handleClicks(ActionEvent event) {
    }

    @FXML
    private void SendComplain(ActionEvent event) {
           conn = Mysqlconnect.ConnectDb();
        String sql ="insert into complains(catergory, complain) values(?,?)";
        
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(1,typeCombo.getValue().toString());
            pst.setString(2,txtcomplainarea.getText());
           
          
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Your Complain Is Send, We will get back to you with solution");
            
        } catch(SQLException ex){
       Logger.getLogger(AddingUserController.class.getName()).log(Level.SEVERE, null,ex);
       }
    }

    @FXML
    private void Logout(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
        paneComplaining.getChildren().setAll(pane);
    }
    
}
