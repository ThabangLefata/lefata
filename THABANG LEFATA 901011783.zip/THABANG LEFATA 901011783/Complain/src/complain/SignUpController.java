/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;


public class SignUpController implements Initializable {

    @FXML
    private JFXTextField txtid;
    @FXML
    private JFXTextField txtname;
    @FXML
    private JFXTextField txtlastname;
    @FXML
    private JFXTextField txtemail;
    @FXML
    private JFXTextField txtpassword;
    @FXML
    private JFXComboBox type;
    @FXML
    private JFXButton btnsignup;
    @FXML
    private JFXButton btnback;
    
   java.sql.Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    @FXML
    private AnchorPane paneRegister;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       type.getItems().addAll("Student","Lecture", "Security","Others");
    }    
     @FXML
    private void Register() {
        
        conn = Mysqlconnect.ConnectDb();
        String sql ="insert into users(id, name, lastname, catergory, email, password) values(?,?,?,?,?,?)";
        
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(4,type.getValue().toString());
            pst.setString(2,txtname.getText());
            pst.setString(3,txtlastname.getText());
            pst.setString(5,txtemail.getText());
            pst.setString(1,txtid.getText());
            pst.setString(6,txtpassword.getText());
          
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Welcome!! You Have Succefully SignUp, Now You Can Log In");
            
             AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
            paneRegister.getChildren().setAll(pane);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @FXML
    private void back(ActionEvent event) throws IOException {
         AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
            paneRegister.getChildren().setAll(pane);
    }

}
  /* private void handleClick(MouseEvent event) throws IOException {
        if(event.getSource() == btnsignup){
          
          AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
          paneRegister.getChildren().setAll(pane);
    }
    }*/

