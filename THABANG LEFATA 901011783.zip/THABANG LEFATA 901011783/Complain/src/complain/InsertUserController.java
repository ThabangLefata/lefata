/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;


public class InsertUserController implements Initializable {

    @FXML
    private JFXTextField txtaddId;
    @FXML
    private JFXTextField txtaddname;
    @FXML
    private JFXTextField txtlastname;
    @FXML
    private JFXTextField txtaddemail;
    @FXML
    private JFXComboBox addcategory;
    @FXML
    private Button btnadduser;
    
    java.sql.Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    @FXML
    private AnchorPane adduserPane;
    @FXML
    private JFXTextField txtaddpassword;
    @FXML
    private Button btngo;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        addcategory.getItems().addAll("Student","Lecture", "Security","Management","Others"); 
    }    

    @FXML
    private void AddUser(ActionEvent event) {
        conn = Mysqlconnect.ConnectDb();
        String sql ="insert into users(id, name, lastname,email, catergory, password) values(?,?,?,?,?,?)";
        
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(1,txtaddId.getText());
            pst.setString(2,txtaddname.getText());
            pst.setString(3,txtlastname.getText());
            pst.setString(4,txtaddemail.getText());
            pst.setString(5,addcategory.getValue().toString());
            pst.setString(6,txtaddpassword.getText());
            
          
             pst.execute();
            
            JOptionPane.showMessageDialog(null, "User Successfully Added");
            
               
            
        } catch(Exception e){
           // JOptionPane.showMessageDialog(null, "Error Occured... Try Again!!!");
        }
    }

   
    }
    

