/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complain;

import complain.usermodels.Users;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class AddingUserController implements Initializable {

    @FXML
    private TableView<Users> tableview_users;
    @FXML
    private TableColumn<Users, String> idcolumn;
    @FXML
    private TableColumn<Users, String> namecolumn;
    @FXML
    private TableColumn<Users, String> lastnamecolumn;
    @FXML
    private TableColumn<Users, String> catergorycolumn;
    @FXML
    private TableColumn<Users, String> emailColum;
    @FXML
    private TableColumn<Users, String> actioncolum;
    @FXML
    private Button adduser;
    
    String query = null;
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    Users user = null;
    
    ObservableList<Users> UsersList = FXCollections.observableArrayList();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadUser();
    }    

    @FXML
    private void search(MouseEvent event) {
    }

    @FXML
    private void refreshTable(MouseEvent event) {
    }

  
 
    private void loadUser() {
       try{
         conn = Mysqlconnect.ConnectDb();
         ResultSet rs = conn.createStatement().executeQuery("select * from users");
         while (rs.next()){
         
             UsersList.add(new Users(rs.getString("id"),
             rs.getString("name"), rs.getString("lastname"),rs.getString("category"),rs.getString("email")));
         }
       }catch(SQLException ex){
       Logger.getLogger(AddingUserController.class.getName()).log(Level.SEVERE, null,ex);
       
       
      
        
       }
        
       idcolumn.setCellValueFactory(new PropertyValueFactory<>("id"));
       namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
       lastnamecolumn.setCellValueFactory(new PropertyValueFactory<>("lastname"));
       catergorycolumn.setCellValueFactory(new PropertyValueFactory<>("category"));
       emailColum.setCellValueFactory(new PropertyValueFactory<>("email"));
       actioncolum.setCellValueFactory(new PropertyValueFactory<>("action"));
       
       tableview_users.setItems(UsersList);
    }
        
}
